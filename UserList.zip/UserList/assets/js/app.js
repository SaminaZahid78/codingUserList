// regular expression for validation
const strRegex =  /^[a-zA-Z\s]*$/; // containing only letters
const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
/* supports following number formats - (123) 456-7890, (123)456-7890, 123-456-7890, 123.456.7890, 1234567890, +31636363634, 075-63546725 */
const digitRegex = /^\d+$/;

// -------------------------------------------------- //

const fullscreenDiv = document.getElementById('fullscreen-div');
const modal = document.getElementById('modal');
const addBtn = document.getElementById('add-btn');
const closeBtn = document.getElementById('close-btn');
const modalBtns = document.getElementById('modal-btns');
const form = document.getElementById('modal');
const userList = document.querySelector('#user-book-list tbody');

// -------------------------------------------------- //
let firstName = lastName = email  = role = userstatus = "";

// User class
class User{
    constructor(id, firstName, lastName, email, role, userstatus){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.role = role;
        this.userstatus = userstatus;
    }

    static getUsers(){
        // from local storage
        let users;
        if(localStorage.getItem('users') == null){
            users = [];
        } else {
            users = JSON.parse(localStorage.getItem('users'));
        }
        return users;
    }

    static addUser(user){
        const users = User.getUsers();
        users.push(user);
        localStorage.setItem('users', JSON.stringify(users));
    }

    static deleteUser(id){
        const users = User.getUsers();
        users.forEach((user, index) => {
            if(user.id == id){
                users.splice(index, 1);
            }
        });
        localStorage.setItem('users', JSON.stringify(users));
        form.reset();
        UI.closeModal();
        userList.innerHTML = "";
        UI.showUserList();
    }

    static updateUser(item){
        const users = User.getUsers();
        users.forEach(user => {
            if(user.id == item.id){
                user.firstName = item.firstName;
                user.lastName = item.lastName;
                user.email = item.email;
                user.role = item.role;
                user.userstatus = item.userstatus;
            }
        });
        localStorage.setItem('users', JSON.stringify(users));
        userList.innerHTML = "";
        UI.showUserList();
    }
}

// UI class
class UI{
    static showUserList(){
        const users = User.getUsers();
        users.forEach(user => UI.addToUserList(user));
    }

    static addToUserList(user){
        const tableRow = document.createElement('tr');
        tableRow.setAttribute('data-id', user.id);
        tableRow.innerHTML = `
            <td>${user.id}</td>
            <td><span>${user.role}</span></td>
            <td>${user.firstName}</td>
            <td>${user.lastName}</td>
            <td>${user.email}</td>
            <td>${user.userstatus}</td>
        `;
        userList.appendChild(tableRow);
    }

    static showModalData(id){
        const users = User.getUsers();
        users.forEach(user => {
            if(user.id == id){
                form.first_name.value = user.firstName;
                form.last_name.value = user.lastName;
                form.email.value = user.email;
                form.role.value = user.role;
                form.userstatus.value = user.userstatus;
                document.getElementById('modal-title').innerHTML = "Change User Details";

                document.getElementById('modal-btns').innerHTML = `
                    <button type = "submit" id = "update-btn" data-id = "${id}">Update </button>
                    <button type = "button" id = "delete-btn" data-id = "${id}">Delete </button>
                `;
            }
        });
    }

    static showModal(){
        modal.style.display = "block";
        fullscreenDiv.style.display = "block";
    }

    static closeModal(){
        modal.style.display = "none";
        fullscreenDiv.style.display = "none";
    }

}

// DOM Content Loaded
window.addEventListener('DOMContentLoaded', () => {
    eventListeners();
    UI.showUserList();
});

// event listeners
function eventListeners(){
    // show add item modal
    addBtn.addEventListener('click', () => {
        form.reset();
        document.getElementById('modal-title').innerHTML = "Add New User";
        UI.showModal();
        document.getElementById('modal-btns').innerHTML = `
            <button type = "submit" id = "save-btn"> Save </button>
        `;
    });

    // close add item modal
    closeBtn.addEventListener('click', UI.closeModal);

    // add an User item
    modalBtns.addEventListener('click', (event) => {
        event.preventDefault();
        if(event.target.id == "save-btn"){
            let isFormValid = getFormData();
            if(!isFormValid){
                form.querySelectorAll('input').forEach(input => {
                    setTimeout(() => {
                        input.classList.remove('errorMsg');
                    }, 1500);
                });
            } else {
                let allItem = User.getUsers();
                let lastItemId = (allItem.length > 0) ? allItem[allItem.length - 1].id : 0;
                lastItemId++;

                const userItem = new User(lastItemId, firstName, lastName, email, role, userstatus);
                User.addUser(userItem);
                UI.closeModal();
                UI.addToUserList(userItem);
                form.reset();
            }
        }
    });

    // table row items
    userList.addEventListener('click', (event) => {
        UI.showModal();
        let trElement;
        if(event.target.parentElement.tagName == "TD"){
            trElement = event.target.parentElement.parentElement;
        }

        if(event.target.parentElement.tagName == "TR"){
            trElement = event.target.parentElement;
        }

        let viewID = trElement.dataset.id;
        UI.showModalData(viewID);
    });

    // delete an user item
    modalBtns.addEventListener('click', (event) => {
        if(event.target.id == 'delete-btn'){
            User.deleteUser(event.target.dataset.id);
        }
    });

    // update an user item
    modalBtns.addEventListener('click', (event) => {
        event.preventDefault();
        if(event.target.id == "update-btn"){
            let id = event.target.dataset.id;
            let isFormValid = getFormData();
            if(!isFormValid){
                form.querySelectorAll('input').forEach(input => {
                    setTimeout(() => {
                        input.classList.remove('errorMsg');
                    }, 1500);
                });
            } else {
                const userItem = new User(id, firstName, lastName, email, role, userstatus);
                User.updateUser(userItem);
                UI.closeModal();
                form.reset();
            }
        }
    });
}

// get form data
function getFormData(){
    console.log('inform')
    let inputValidStatus = [];
    if(!strRegex.test(form.first_name.value) || form.first_name.value.trim().length == 0){
        addErrMsg(form.first_name);
        inputValidStatus[1] = false;
    } else {
        firstName = form.first_name.value;
        inputValidStatus[1] = true;
    }

    if(!strRegex.test(form.last_name.value) || form.last_name.value.trim().length == 0){
        addErrMsg(form.last_name);
        inputValidStatus[2] = false;
    } else {
        lastName = form.last_name.value;
        inputValidStatus[2] = true;
    }

    if(!emailRegex.test(form.email.value)){
        addErrMsg(form.email);
        inputValidStatus[3] = false;
    } else {
        email = form.email.value;
        inputValidStatus[3] = true;
    }
    role = form.role.value;
    userstatus = form.userstatus.value;
    return inputValidStatus.includes(false) ? false : true;
}


function addErrMsg(inputBox){
    inputBox.classList.add('errorMsg');
}